# file sage/core/sage_memory/memory_collection/graph_collection.py
from sage_memory.memory_collection.base_collection import BaseMemoryCollection


class GraphMemoryCollection(BaseMemoryCollection):
    pass

    @classmethod
    def load(cls,  a, b):
        pass

